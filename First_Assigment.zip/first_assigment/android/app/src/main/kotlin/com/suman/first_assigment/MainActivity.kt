package com.suman.first_assigment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
